# webdev-final-project

Description: Displays news from various sources and allows the user to search for keywords, filter by topic, and set favorite topics.

Group Members: Annabel Lin (all273), Justin Hsu (jah574)
Github: https://github.coecis.cornell.edu/all273/webdev-final-project/tree/master/news
